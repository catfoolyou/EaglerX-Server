--------------------------------------------------------------------------------
   Welcome to your new Cuberite server, compatible with Minecraft 1.8 - 1.12!
--------------------------------------------------------------------------------

 - To get started with your server, read the user's manual at
   https://book.cuberite.org/

 - Subscribe to the Newsletter for update news and important information at
   https://cuberite.org/news/#subscribe

 - For information about adding plugins to your server, visit
   https://cuberite.org/plugins/

 - For additional support, visit https://cuberite.org/discuss/

--------------------------------------------------------------------------------

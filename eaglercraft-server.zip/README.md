# Eaglercraft!
I love you ayun
### Cuberite doesn't allow for Bukkit/Spigot plugins.
Plugins can be found here:
[https://plugins.cuberite.org/](Cuberite Plugins)
## I highly reccomend installing a login/auth plugin.
**If a plugin isn't there, don't freak out. Ask me to spend a month porting it to Cuberite and I will!**